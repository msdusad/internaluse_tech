Get user country by IP-address using PHP
=====================================

Quick example which shows how to get user country name by IP-address using PHP.

Read the article here: [http://circlewaves.com/blog/get-user-country-by-ip/](http://circlewaves.com/blog/get-user-country-by-ip/)

GETTING STARTED
----
1. Import table (file 'ip_country_list.sql') to your MySQL database.
 
2. Fill in database settings below.

3. Script is ready!

MIT LICENSE
----
&copy; 2014 Max Kostinevich / [circlewaves.com](http://circlewaves.com)